# EDCommoditiesRoute
ED_CommoditiesRoute est un outils pour calculer la liste minimale des stations contenant les marchandises que l'on souhaite.
ED_CommoditiesRoute va rechercher les stations contenant le plus de type de marchandises en fonction de :
- la liste de marchandises et la quantité de chacune
- la soute du vaisseau
- la station de départ

ED_CommoditiesRoute ne calcule pas dans cette version l'ordre de visite des stations
